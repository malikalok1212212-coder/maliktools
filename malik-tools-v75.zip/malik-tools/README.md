# Malik Tools

Website tools (AM Premium kirim + verifikasi, hapus background, HD gambar, bypass link, link WhatsApp) siap deploy di Vercel.

## Deploy
1. Upload isi folder ini ke GitHub, lalu Import di Vercel (Framework: Other, tanpa build command).
2. Tab Storage → Create → Blob, lalu Connect ke project (otomatis menambah `BLOB_READ_WRITE_TOKEN`). Dipakai untuk unggah foto di tool Hapus background; foto dihapus lagi setelah diproses.
3. Settings → Environment Variables: isi `NEXA_API_KEY` (lihat `.env.example`).
4. Deploy.

## Penting
Semua endpoint mengikuti dokumentasi Nexa: `/am/send/`, `/am/verif/`, `/tools/remove/`, `/tools/hd/`, `/api/bypass`, `/api/ampreset`, `/api/cekprime/`. API key dikirim sebagai `?key=` dan hanya ada di server, tidak pernah ke browser. Isi `ACCESS_CODE` bila halaman tidak boleh dipakai publik.

## TikTok Downloader
Tool bawaan `tiktok-dl`: unduh video tanpa watermark, foto slide, dan musik dari link TikTok. Memakai provider **api-cloud.my.id** (`GET /downloader/tiktok?url=`), tanpa API key, dan key Nexa **tidak pernah dikirim** ke provider ini. Hanya link `tiktok.com`, `vt.tiktok.com`, dan `tt.site` yang diterima. Gratis, tanpa kredit. Opsional: `TIKTOK_API_BASE` dan `TIKTOK_API_PATH` bila alamat provider berubah. 

## Kategori Downloader
Berisi **AIO Downloader** (`/api/aio`), **Snaptik** (`/api/snaptik/`), **CapCut** (`/api/capcut`), **Facebook** (`/api/fb`), **Instagram** (`/api/ig`), **Spotify Play** (`/api/spotifyplay`, parameter `q`), dan **TikTok Downloader**. Semua lewat `GET ?key=&url=` (Spotify `&q=`). Hasil dirapikan jadi daftar tautan Buka / unduh (video, audio, foto). Key Nexa hanya dipakai di server. Path bisa diganti lewat `NEXA_PATH_AIO`. Tool ini gratis di Malik Tools (1 kredit dipakai di akun Nexa). Tool downloader baru: tambah entri di `api/_config.js`, tambah objek di `public/index.html`, lalu beri kategori `dl` di `CAT` dan daftarkan id-nya di `DLI`.

## Kategori Maker
Berisi **Duar Viral** (api-cloud.my.id `/maker/duarviral?url=`, tanpa key Nexa), **IQC Dark** (`/iqc-dark`: teks, waktu, gambar) dan **Fake Call** (`/fakecall`: foto profil, nama, durasi). Tool bertipe `multi` di `api/_config.js` (daftar `fields`), foto bisa diunggah dari perangkat atau lewat link, dan foto sementara dihapus lagi setelah diproses. IQC Dark memakai host `apii.nexadev.my.id` tanpa key (`IQC_API_BASE`), jadi key Nexa tidak dikirim ke sana. Path bisa diganti lewat `NEXA_PATH_IQCDARK` dan `NEXA_PATH_FAKECALL`. Tool Maker baru: tambah entri `multi` di `_config.js`, tambah `canvasTool({...})` di `public/index.html`, beri kategori `canvas` di `CAT` dan daftarkan id-nya di `CVI`.

## Scan Slop
Tool `scan-slop` memakai provider api-cloud.my.id (`GET /tools/scanslop?url=`), tanpa key Nexa. Ada di kategori Tools. Hasil: skor 0-100, vonis, ringkasan, sinyal AI dan manusia, tangkapan layar, dan tautan laporan sniffslop. Penyedia membatasi jumlah pindai (di contoh: sisa 2 dari 3). Host dan path bisa diganti lewat `SCANSLOP_API_BASE` dan `SCANSLOP_API_PATH`.

## Tambah tool
- Server: tambah entri di `api/_config.js` → `tools`.
- Tampilan: tambah objek di array `tools` pada `public/index.html`.

## Unggah foto
File foto sampai 50 MB diterima. Karena batas body fungsi Vercel 4,5 MB, foto di atas 4 MB dikecilkan otomatis di browser (maks. 3000 px, JPG) sebelum diunggah.

## Halaman tambahan
Changelog, Feedback, Stats, dan Profil ada di `public/index.html`. Isi `CONTACT_WA` (format `628xxxxxxxxxx`) agar tombol Feedback langsung membuka chat ke nomor kamu. Entri changelog ada di array `CHANGELOG`. Stats dan Profil disimpan di browser tiap perangkat (localStorage).

## Sistem Developer
1. Isi `DEVELOPER_EMAILS` (email Google kamu, pisahkan koma bila lebih dari satu), pastikan Login Google dan Vercel Blob sudah aktif, lalu redeploy. `OWNER_EMAILS` lama tetap dibaca, jadi deploy yang sudah jalan tidak perlu diubah.
2. Masuk lewat Profil. Menu **Developer** muncul di menu samping.
3. Yang bisa dilakukan developer: melihat semua pengguna yang pernah login (jumlah masuk, terakhir aktif), mengirim peringatan (tampil sebagai popup sampai pengguna menekan "Saya mengerti"), memblokir atau membuka blokir, menghapus pengguna dari daftar, dan mengatur role pengguna. (Fitur tambah tool kustom dari panel sudah dihapus; tool baru ditambah lewat kode.)
4. Data developer disimpan di Upstash Redis (satu entri per pengguna/tool). Data lama di Vercel Blob diimpor otomatis sekali; `SESSION_SECRET` tetap dibutuhkan untuk impor itu dan untuk sesi, jadi jangan diganti. Pemblokiran hanya berlaku untuk pengguna yang login.

## Kredit harian
Hanya **AM Premium** yang memakai kredit; tool lain gratis. Kredit dipotong 1 saat langkah 2 (verifikasi) berhasil, dan tidak dipotong kalau provider gagal. Jatah per 24 jam: **Member 5**, **Premium 15**, **VIP 30**, **Developer tidak memakai kredit sama sekali (tanpa batas, kotak kredit disembunyikan)**. Reset 24 jam dihitung sejak kredit pertama dipakai. AM Premium wajib login karena kredit dicatat per akun (di Upstash Redis bersama data developer, jadi Redis harus aktif; pemotongan kredit atomik). Jatah bisa diubah lewat env `CREDIT_MEMBER`, `CREDIT_PREMIUM`, `CREDIT_VIP`; tool lain yang berkredit diatur di `api/_credits.js` (`CREDIT_TOOLS`).

## Role
Di panel Developer tab Pengguna, tiap pengguna punya pilihan role: **Member** (bawaan semua pengguna), **Premium**, dan **VIP**. Role tampil sebagai badge di Profil dan Chat Global. **Developer** otomatis untuk email di `DEVELOPER_EMAILS` dan tidak bisa diubah dari panel. Saat ini role hanya berupa badge, belum membuka atau membatasi fitur. Badge di pesan chat lama tidak ikut berubah, hanya pesan baru yang memakai role terbaru.

## Pengumuman dan Favorit
Developer bisa memasang pengumuman (maks. 300 karakter) di panel Developer tab Pengumuman. Tampil di beranda dan bisa ditutup per sesi. Pengguna bisa menandai tool favorit dengan ☆, tersimpan di perangkat masing-masing, dan tool favorit naik ke atas daftar.

## Chat Global
Halaman **Chat Global** ada di menu samping. Semua orang bisa membaca, kirim pesan wajib login Google. Nama dan foto Google tampil publik di chat. Ada balas, tag `@nama`, badge role (DEVELOPER, PREMIUM, VIP, MEMBER), jeda 2 detik per pengguna, pengguna yang diblokir tidak bisa kirim, dan developer bisa menghapus pesan. Pesan disimpan (200 terakhir) di Upstash Redis dan dimuat ulang tiap 5 detik.

### Foto dan sticker di chat
Tombol kamera mengirim foto (JPG, PNG, WebP). Foto dikecilkan di browser (maks. 1280 px, JPG) lalu disimpan di Vercel Blob folder `chat/`, jeda 8 detik per pengguna. Foto ikut terhapus dari Blob saat developer menghapus pesannya atau saat pesan lama terpotong dari 200 pesan terakhir. Alamat foto bersifat publik bagi yang punya link. Tombol senyum membuka 30 sticker bawaan (24 emoji dan 6 stiker teks). Untuk menambah sticker, ubah array `STK` di `public/index.html` dan angka `STICKERS` di `api/chat.js`.

## Login Google
1. Buka console.cloud.google.com, pilih atau buat project, lalu isi OAuth consent screen.
2. APIs & Services > Credentials > Create credentials > OAuth client ID > Web application.
3. Authorized JavaScript origins: isi alamat situs (contoh `https://nama-kamu.vercel.app`, plus domain sendiri bila ada). Redirect URI tidak perlu diisi.
4. Di Vercel > Settings > Environment Variables isi `GOOGLE_CLIENT_ID` (Client ID dari langkah 3) dan `SESSION_SECRET` (acak, minimal 32 karakter, mis. hasil `openssl rand -hex 32`), lalu redeploy.
5. Opsional: `ALLOWED_EMAILS` membatasi ke email tertentu.

Selama consent screen berstatus Testing, hanya akun yang didaftarkan sebagai test user yang bisa masuk. Ubah ke Production agar terbuka untuk umum.

## Wajib login + akun username/password + SMTP
Semua orang yang membuka situs harus masuk dulu. Layar login muncul di atas halaman, dan server juga menolak (401) pemakaian tool, unggah foto, dan Chat Global tanpa sesi login. Isi `REQUIRE_LOGIN=0` hanya bila situs ingin dibuka untuk tamu.

Cara masuk: **Google** atau **username + kata sandi**. Daftar akun baru memakai email, lalu kode 6 digit dikirim lewat SMTP dan harus dimasukkan sebelum akun dibuat. Ada juga **Lupa kata sandi** (kode reset lewat email).

### Pengaturan SMTP (Environment Variables Vercel)
`SMTP_HOST`, `SMTP_PORT` (465 SSL atau 587 STARTTLS), `SMTP_USER`, `SMTP_PASS`, opsional `SMTP_FROM`, `SMTP_SECURE`, `APP_NAME`. Untuk Gmail pakai App Password (bukan kata sandi biasa) dengan host `smtp.gmail.com`, port 465. Setelah mengisi, redeploy dan jalankan `npm install` (dependensi baru: `nodemailer`).

### Catatan keamanan
- Kata sandi disimpan sebagai hash scrypt + salt acak, bukan teks asli. Akun disimpan di Upstash Redis, seperti data developer.
- Kode berlaku 10 menit, maksimal 5 kali salah, kirim ulang minimal jeda 1 menit. Akun dikunci 10 menit setelah 8 kali salah kata sandi.
- Respons Lupa kata sandi sama untuk email terdaftar maupun tidak, agar email tidak bisa ditebak.
- Pengguna username/password muncul di panel Developer, bisa diblokir, diberi peringatan, dan diberi role seperti pengguna Google.
- Penyimpanan akun memakai file JSON tunggal. Untuk ribuan pengguna sebaiknya pindah ke database (Redis/Postgres).


## Notifikasi tool baru ke bot WhatsApp
Saat Developer menambah tool kustom, server mengirim pengumuman ke bot WhatsApp (POST `/api/channel/new-tool`, header `x-internal-key`). Isi di Vercel:
- `BOT_WEBHOOK_URL`: alamat publik API internal bot, contoh `https://bot.cloudstore.my.id`
- `BOT_SECRET`: sama dengan `BOT_INTERNAL_API_KEY` di `.env` bot
- `BOT_WEBHOOK_PATH` (opsional): bawaan `/api/channel/new-tool`

Hanya id, nama, deskripsi, kategori, dan tipe tool yang dikirim. Gagal kirim tidak membatalkan simpan tool; sistem mencoba ulang sekali. Bila tetap gagal, panel menampilkan alasannya, dan menonaktifkan lalu mengaktifkan kembali tool tersebut akan mengirim ulang pengumuman (hanya untuk tool yang belum pernah berhasil diumumkan).

## Upstash Redis dan pembersihan foto

1. Vercel → Storage/Marketplace → Upstash Redis → Create, lalu Connect ke project (otomatis mengisi `KV_REST_API_URL` dan `KV_REST_API_TOKEN`).
2. Isi `CRON_SECRET` (acak). Cron harian `/api/cleanup` (03.00 UTC) menghapus foto di `uploads/` yang lebih tua dari 2 jam dan tidak terhapus oleh tool.
3. Pembatas laju (login, tool, unggah, jeda chat) kini memakai Redis, jadi berlaku lintas instance. Tanpa Redis ia jatuh ke memori.
4. Redeploy. Saat pertama kali dibuka, data lama di Blob (state/akun/chat) diimpor otomatis tanpa menimpa data yang sudah ada di Redis. Blob tetap dipakai untuk foto.

## Jalur cadangan dan pesan error provider
- Balasan HTML dari provider (halaman Cloudflare "Just a moment...", 503, dll) tidak lagi tampil mentah. Pengguna melihat pesan singkat yang jelas.
- **TikTok Downloader** dan **Snaptik** punya jalur cadangan ke **AIO Nexa** (`fallback: 'aio-dl'` di `api/_config.js`). Bila provider utama gagal atau diblokir, permintaan otomatis dialihkan. Jalur cadangan memakai kuota Nexa (`NEXA_API_KEY`), bukan kredit pengguna.
- Kegagalan sementara provider (HTTP 5xx, koneksi putus) diulang otomatis untuk tool yang aman diulang (IQC Dark, Fake Call, Duar Viral, Scan Slop, TikTok, Snaptik) lewat `retries` di `api/_config.js`. Tool yang berefek samping (kirim email, buat token) tidak diulang.
- Total waktu satu permintaan dijaga di bawah 57 detik (`maxDuration` `api/tool.js` di `vercel.json` = 60 detik).
