// Semua pengaturan provider ada di sini. Tambah tool baru = tambah satu entri di "tools".
module.exports = {
  base: (process.env.NEXA_BASE_URL || 'https://api.nexadev.my.id').replace(/\/$/, ''),
  key: process.env.NEXA_API_KEY || '',
  emailField: process.env.NEXA_EMAIL_FIELD || 'email',
  tools: {
    // GET /api/cekprime/?key=<API key>&points=<angka> (dokumentasi Nexa: Cek Prime, 1 kredit)
    'cek-prime': { type: 'number', path: process.env.NEXA_PATH_CEKPRIME || '/api/cekprime/', method: 'GET', param: 'points', keyParam: 'key' },
    // GET /api/ampreset?key=<API key>&url=<link TikTok> (dokumentasi Nexa: ampreset, 1 kredit)
    'am-preset': { type: 'url', path: process.env.NEXA_PATH_AM_PRESET || '/api/ampreset', method: 'GET', param: 'url', keyParam: 'key' },
    // GET /am/verif/?key=<API key>&email=<email>&link=<link login dari email> (AM Premium - Verif)
    'am-verif': { type: 'email-link', path: process.env.NEXA_PATH_AM_VERIF || '/am/verif/', method: 'GET', param: 'email', linkParam: 'link', keyParam: 'key' },
    // GET /am/send/?key=<API key>&email=<email> (sesuai dokumentasi Nexa: AM Premium - Send)
    'am-send': { type: 'email', path: process.env.NEXA_PATH_AM_SEND || '/am/send/', method: 'GET', param: 'email', keyParam: 'key' },
    // GET /tools/remove/?key=<API key>&url=<link gambar> (dokumentasi Nexa: Remove Background, 1 kredit)
    // GET /tools/hd/?image=<link gambar> (parameternya "image")
    'hd-gambar': { type: 'url', path: process.env.NEXA_PATH_HD || '/tools/hd/', method: 'GET', param: 'image', keyParam: 'key' },
    // GET /api/bypass?key=<API key>&url=<link pendek> (key dikirim lewat query, hanya dari server)
    'bypass-link': { type: 'url', path: process.env.NEXA_PATH_BYPASS || '/api/bypass', method: 'GET', param: 'url', keyParam: 'key' },
    // TikTok Downloader: provider api-cloud.my.id (tanpa key Nexa, base sendiri). GET /downloader/tiktok?url=<link TikTok>
    'tiktok-dl': { type: 'url', base: (process.env.TIKTOK_API_BASE || 'https://api-cloud.my.id').replace(/\/$/, ''), path: process.env.TIKTOK_API_PATH || '/downloader/tiktok', method: 'GET', param: 'url', shape: 'tiktok', timeout: 15000, fallback: 'aio-dl', retries: 1, host: /(^|\.)(tiktok\.com|tt\.site)$/i },
    // GET /api/rch?key=<API key>&url=<link pesan channel WhatsApp>&reaction=<emoji> (dokumentasi Nexa: Reaction Channel)
    'react-channel': { type: 'url', extra: true, path: process.env.NEXA_PATH_RCH || '/api/rch', method: 'GET', param: 'url', linkParam: 'reaction', keyParam: 'key', host: /(^|\.)whatsapp\.com$/i, hostMsg: 'Link harus berupa link pesan channel WhatsApp (https://whatsapp.com/channel/...).' },
    // GET /api/wink?key=<API key>&url=<link foto wajah> (dokumentasi Nexa: wink, 1 kredit di Nexa)
    'wink': { type: 'url', path: process.env.NEXA_PATH_WINK || '/api/wink', method: 'GET', param: 'url', keyParam: 'key', timeout: 55000 },
    // GET /api/netflix?key=<API key>&targetCountry=<kode negara 2 huruf, mis. IN> (dokumentasi Nexa: Netflix token, 1 kredit di Nexa)
    'netflix-token': { type: 'text', upper: true, pattern: /^[A-Z]{2}$/, patternMsg: 'Isi kode negara 2 huruf, contoh: IN, ID, US.', path: process.env.NEXA_PATH_NETFLIX || '/api/netflix', method: 'GET', param: 'targetCountry', keyParam: 'key', timeout: 55000 },
    // GET /api/tiktokstalker?key=<API key>&username=<username TikTok> (dokumentasi Nexa: tiktok stalker, 1 kredit di Nexa)
    'tiktok-stalker': { type: 'text', stripAt: true, pattern: /^[A-Za-z0-9._]{2,24}$/, patternMsg: 'Username TikTok tidak valid. Gunakan huruf, angka, titik, atau garis bawah (2-24 karakter).', path: process.env.NEXA_PATH_TIKTOKSTALKER || '/api/tiktokstalker', method: 'GET', param: 'username', keyParam: 'key', timeout: 30000 },
    // GET /api/aio?key=<API key>&url=<link video/audio/reels> (dokumentasi Nexa: AIO Downloader, 1 kredit di Nexa). Kategori Downloader.
    'aio-dl': { type: 'url', path: process.env.NEXA_PATH_AIO || '/api/aio', method: 'GET', param: 'url', keyParam: 'key', shape: 'aio', timeout: 45000 },
    // Kategori Downloader (Nexa, 1 kredit di Nexa): snaptik, capcut, fb, ig, spotifyplay
    'snaptik-dl': { type: 'url', path: process.env.NEXA_PATH_SNAPTIK || '/api/snaptik/', method: 'GET', param: 'url', keyParam: 'key', shape: 'aio', timeout: 20000, fallback: 'aio-dl', retries: 1, host: /(^|\.)(tiktok\.com|tt\.site)$/i },
    'capcut-dl': { type: 'url', path: process.env.NEXA_PATH_CAPCUT || '/api/capcut', method: 'GET', param: 'url', keyParam: 'key', shape: 'aio', timeout: 40000, host: /(^|\.)capcut\.com$/i, hostMsg: 'Link harus dari CapCut (capcut.com).' },
    'fb-dl': { type: 'url', path: process.env.NEXA_PATH_FB || '/api/fb', method: 'GET', param: 'url', keyParam: 'key', shape: 'aio', timeout: 40000, host: /(^|\.)(facebook\.com|fb\.watch|fb\.com)$/i, hostMsg: 'Link harus dari Facebook (facebook.com atau fb.watch).' },
    'ig-dl': { type: 'url', path: process.env.NEXA_PATH_IG || '/api/ig', method: 'GET', param: 'url', keyParam: 'key', shape: 'aio', timeout: 40000, host: /(^|\.)instagram\.com$/i, hostMsg: 'Link harus dari Instagram (instagram.com).' },
    'spotify-play': { type: 'text', path: process.env.NEXA_PATH_SPOTIFYPLAY || '/api/spotifyplay', method: 'GET', param: 'q', keyParam: 'key', shape: 'aio', timeout: 45000 },
    // Kategori Canvas (Nexa): beberapa isian + foto. GET /iqc-dark?text=&time=&url=  dan  GET /fakecall?ppurl=&name=&duration=
    'iqc-dark': { type: 'multi', base: (process.env.IQC_API_BASE || 'https://apii.nexadev.my.id').replace(/\/$/, ''), path: process.env.NEXA_PATH_IQCDARK || '/iqc-dark', method: 'GET', timeout: 20000, retries: 2, fields: [
      { key: 'text', label: 'Teks', req: true, max: 300 }, { key: 'time', label: 'Waktu', max: 10 }, { key: 'url', label: 'Gambar', kind: 'url', req: true }] },
    'fake-call': { type: 'multi', path: process.env.NEXA_PATH_FAKECALL || '/fakecall', method: 'GET', keyParam: 'key', timeout: 25000, retries: 1, fields: [
      { key: 'ppurl', label: 'Foto profil', kind: 'url', req: true }, { key: 'name', label: 'Nama', req: true, max: 60 }, { key: 'duration', label: 'Durasi', req: true, max: 10 }] },
    // Scan Slop: provider api-cloud.my.id (tanpa key Nexa). GET /tools/scanslop?url=<link>
    'scan-slop': { type: 'url', base: (process.env.SCANSLOP_API_BASE || 'https://api-cloud.my.id').replace(/\/$/, ''), path: process.env.SCANSLOP_API_PATH || '/tools/scanslop', method: 'GET', param: 'url', timeout: 25000, retries: 1 },
    // Duar Viral: provider api-cloud.my.id (tanpa key Nexa). GET /maker/duarviral?url=<link gambar>. Kategori Maker.
    'duar-viral': { type: 'multi', base: (process.env.DUARVIRAL_API_BASE || 'https://api-cloud.my.id').replace(/\/$/, ''), path: process.env.DUARVIRAL_API_PATH || '/maker/duarviral', method: 'GET', timeout: 25000, retries: 1, fields: [
      { key: 'url', label: 'Gambar', kind: 'url', req: true }] },
    'hapus-background': { type: 'url', path: process.env.NEXA_PATH_REMOVE || '/tools/remove/', method: 'GET', param: 'url', keyParam: 'key' }
  }
};
