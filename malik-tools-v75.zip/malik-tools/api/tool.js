const cfg = require('./_config');
const { getUser, isOwner, loginRequired, roleOf } = require('./_auth');
const credits = require('./_credits');
const store = require('./_store');
let blob = null;
try { blob = require('@vercel/blob'); } catch (e) { /* opsional */ }

const rate = require('./_rate');

// Respons fungsi Vercel dibatasi 4,5 MB. Base64 membesarkan data ±33%, jadi gambar mentah maksimal ±3,2 MB (≈4,3 MB setelah base64).
const MAX_IMG_RAW = 3200000;

const PREFER = ['result', 'output', 'image', 'url', 'link'];
function findLink(v, skip) {
  if (typeof v === 'string') { const m = v.match(/https?:\/\/[^\s"'<>]+/); return m && m[0] !== skip ? m[0] : null; }
  if (v && typeof v === 'object') {
    for (const k of PREFER) if (k in v) { const f = findLink(v[k], skip); if (f) return f; }
    for (const k of Object.keys(v)) { const f = findLink(v[k], skip); if (f) return f; }
  }
  return null;
}


// ---- TikTok Downloader: ambil video / foto / musik dari berbagai bentuk balasan api-cloud ----
const IMG_EXT = /\.(jpe?g|png|webp|heic|avif)(\?|$)/i;
const VID_EXT = /\.(mp4|mov|webm)(\?|$)/i;
const isHttp = (u) => typeof u === 'string' && /^https?:\/\//i.test(u);
function pickUrl(it) {
  if (!it) return null;
  if (typeof it === 'string') return it;
  if (Array.isArray(it)) return pickUrl(it[0]);
  return it.url || it.display_url || it.image_url || it.imageUrl || it.download_url || it.src || it.link || pickUrl(it.url_list) || pickUrl(it.urlList) || null;
}
function tiktok(raw) {
  const r = (raw && (raw.data || raw.result)) || raw;
  if (!r || typeof r !== 'object') return null;
  const type = String(r.type || r.media_type || r.mediaType || '').toLowerCase();
  const photoType = /image|photo|slide|carousel/.test(type);
  let imgs = [];
  for (const c of [r.images, photoType ? r.download : null, r.photos, r.pictures, r.slides, r.slideshow, r.image_post && r.image_post.images, r.media && r.media.images]) {
    if (!c) continue;
    const urls = (Array.isArray(c) ? c : [c]).map(pickUrl).filter((u) => isHttp(u) && !VID_EXT.test(u));
    if (urls.length) { imgs = [...new Set(urls)]; break; }
  }
  let video = null;
  const vlist = [r.no_watermark, r.video, r.play, r.nowm, r.nwm, r.hd, r.download_url, r.video_data && r.video_data.nwm, typeof r.media === 'string' ? r.media : null, r.url, r.with_watermark];
  for (const v of vlist) { const u = pickUrl(v); if (isHttp(u) && !IMG_EXT.test(u)) { video = u; break; } }
  const mu = pickUrl(r.music) || pickUrl(r.audio) || (r.music_info && (pickUrl(r.music_info.play) || pickUrl(r.music_info.url)));
  const photo = photoType ? imgs.length > 0 : (/video/.test(type) ? false : (imgs.length && video ? imgs.length > 1 : imgs.length > 0));
  if (!photo && !video) return null;
  const a = r.author;
  const author = (a && (a.nickname || a.username || a.name)) || (typeof a === 'string' ? a : '') || r.nickname || '';
  const data = { judul: String(r.title || r.desc || r.caption || r.description || '').slice(0, 300), penulis: String(author || '').slice(0, 80), jenis: photo ? 'Foto slide' : 'Video' };
  if (photo) { data.jumlah_foto = imgs.length; imgs.slice(0, 20).forEach((u, i) => { data['foto_' + (i + 1)] = u; }); }
  else data.video = video;
  if (isHttp(mu)) data.musik = mu;
  return { link: photo ? imgs[0] : video, data };
}

// ---- AIO Downloader (Nexa /api/aio): rapikan daftar media (video / audio / foto) dari berbagai bentuk balasan ----
function aio(raw) {
  const r = (raw && (raw.data || raw.result)) || raw;
  if (!r || typeof r !== 'object') return null;
  const root = Array.isArray(r) ? { medias: r } : r;
  let list = null;
  for (const k of ['medias', 'media', 'links', 'downloads', 'download', 'formats', 'urls', 'items', 'result', 'data']) {
    const c = root[k]; if (Array.isArray(c) && c.length) { list = c; break; }
  }
  const found = [];
  const kindOf = (u, hint) => {
    const h = String(hint || '').toLowerCase();
    if (IMG_EXT.test(u) || /image|photo|foto/.test(h)) return 'foto';
    if (/audio|mp3|m4a|opus|aac|music/.test(h) && !/video|mp4/.test(h)) return 'audio';
    if (/\.(mp3|m4a|opus|aac)(\?|$)/i.test(u)) return 'audio';
    return 'video';
  };
  if (list) {
    for (const it of list) {
      const u = pickUrl(it); if (!isHttp(u)) continue;
      const o = (it && typeof it === 'object') ? it : {};
      const hint = [o.type, o.mime, o.mimeType, o.extension, o.ext, o.format, o.kind].filter(Boolean).join(' ');
      found.push({ u, kind: kindOf(u, hint), label: String(o.quality || o.resolution || o.label || o.format || o.ext || o.extension || '').slice(0, 20) });
    }
  } else {
    for (const [k, kind] of [['video', 'video'], ['no_watermark', 'video'], ['nowm', 'video'], ['hd', 'video'], ['sd', 'video'], ['url', null], ['download_url', null], ['audio', 'audio'], ['music', 'audio'], ['mp3', 'audio'], ['download', null], ['link', null], ['image', 'foto'], ['images', 'foto'], ['photos', 'foto']]) {
      const v = root[k];
      for (const it of (Array.isArray(v) ? v : [v])) {
        const u = pickUrl(it); if (!isHttp(u)) continue;
        found.push({ u, kind: kind || kindOf(u, ''), label: (k === 'hd' || k === 'sd') ? k.toUpperCase() : '' });
      }
    }
  }
  const seen = new Set(), items = [];
  for (const f of found) { if (!seen.has(f.u)) { seen.add(f.u); items.push(f); } }
  if (!items.length) return null;
  const a = root.author;
  const data = { judul: String(root.title || root.desc || root.caption || root.description || root.name || '').slice(0, 300) };
  const pen = (a && (a.nickname || a.username || a.name)) || (typeof a === 'string' ? a : '') || root.nickname || root.uploader || (typeof root.artist === 'string' ? root.artist : (root.artist && root.artist.name) || '') || '';
  if (pen) data.penulis = String(pen).slice(0, 80);
  const src = root.source || root.platform || root.site || root.extractor || '';
  if (src && typeof src === 'string') data.sumber = src.slice(0, 40);
  const used = {};
  items.slice(0, 20).forEach((f) => {
    const base = f.kind + (f.label ? '_' + f.label.replace(/[^\w]+/g, '') : '');
    used[base] = (used[base] || 0) + 1;
    data[used[base] > 1 ? base + '_' + used[base] : base] = f.u;
  });
  if (!data.judul) delete data.judul;
  const first = items.find((f) => f.kind === 'video') || items.find((f) => f.kind === 'audio') || items[0];
  return { link: first.u, data };
}

// Provider yang membalas JSON dengan gambar berupa data URI (mis. {"result":"data:image/jpeg;base64,..."}): ambil sebagai link gambar
function findDataImage(v, depth) {
  if (typeof v === 'string') return /^data:image\/(jpe?g|png|webp|gif);base64,/i.test(v) ? v : null;
  if (!v || typeof v !== 'object' || (depth || 0) > 3) return null;
  for (const k of PREFER) if (k in v) { const f = findDataImage(v[k], (depth || 0) + 1); if (f) return f; }
  for (const k of Object.keys(v)) { const f = findDataImage(v[k], (depth || 0) + 1); if (f) return f; }
  return null;
}
function stripDataImage(v, img, depth) {
  if (typeof v === 'string') return v === img ? '(gambar)' : v;
  if (!v || typeof v !== 'object' || (depth || 0) > 3) return v;
  const o = Array.isArray(v) ? [] : {};
  for (const k of Object.keys(v)) o[k] = stripDataImage(v[k], img, (depth || 0) + 1);
  return o;
}

// Balasan HTML dari provider (halaman Cloudflare "Just a moment...", 503, dll) tidak boleh tampil mentah ke pengguna
function htmlProblem(status, text) {
  const t = String(text || '').slice(0, 3000);
  if (!/^\s*<(!doctype|html|head|body|\?xml)/i.test(t)) return null;
  if (/just a moment|challenges\.cloudflare\.com|cf[-_]chl|attention required|enable javascript and cookies/i.test(t))
    return { msg: 'Provider memblokir akses dari server (verifikasi Cloudflare). Coba lagi nanti atau pakai tool lain.' };
  if (status === 429) return { msg: 'Provider membatasi permintaan (HTTP 429). Coba lagi beberapa saat lagi.' };
  if (status >= 500) return { msg: 'Server provider sedang down atau sibuk (HTTP ' + status + '). Coba lagi beberapa saat lagi.', transient: true };
  return { msg: 'Provider membalas halaman yang tidak dikenali (HTTP ' + status + '). Coba lagi nanti.' };
}

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const fail = (code, error) => res.status(code).json({ ok: false, error });

  if (req.method === 'GET' && req.query && req.query.credits) { // sisa kredit pengguna yang sedang masuk
    const u = getUser(req);
    if (!u) return fail(401, 'Masuk dulu untuk melihat kredit.');
    try {
      const rec = await store.getUser(u.sub);
      return res.status(200).json({ ok: true, credits: credits.info(rec, roleOf(u.email, rec)) });
    } catch (e) { return fail(503, 'Data kredit belum bisa dibaca.'); }
  }
  if (req.method !== 'POST') return fail(405, 'Metode tidak diizinkan.');
  if (process.env.ACCESS_CODE && req.headers['x-access-code'] !== process.env.ACCESS_CODE)
    return fail(401, 'Kode akses salah atau belum diisi.');
  if (loginRequired() && !getUser(req))
    return fail(401, 'Masuk dulu untuk memakai tool ini.');
  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'x';
  if (await rate.limited('tool', ip, 20, 60)) return fail(429, 'Terlalu banyak permintaan. Coba lagi sebentar lagi.');
  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = {}; } }
  body = body || {};
  // Nama tool datang dari pengguna: hanya kunci milik sendiri yang sah ("constructor", "__proto__" bukan tool)
  const tid = typeof body.tool === 'string' ? body.tool : '';
  let tool = Object.prototype.hasOwnProperty.call(cfg.tools, tid) ? cfg.tools[tid] : null;
  const custom = null;
  const me = getUser(req);
  if (me && !isOwner(me.email) && await store.isBanned(me.sub)) return fail(403, 'Akun kamu diblokir oleh developer.');
  if (!tool) return fail(400, 'Tool tidak dikenal.');
  if (!tool.base && !cfg.key) return fail(500, 'NEXA_API_KEY belum diatur di Environment Variables Vercel.');

  let input = String(body.input !== undefined ? body.input : body.email || '').trim();
  let link2 = '', multi = null;
  if (tool.type === 'email' || tool.type === 'email-link') {
    input = input.toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(input)) return fail(400, 'Format email tidak valid.');
    if (tool.type === 'email-link') {
      link2 = String(body.link || '').trim();
      if (!link2 || link2.length > 2000) return fail(400, 'Isi link atau kode verifikasi dari email (maksimal 2000 karakter).');
    }
  } else if (tool.type === 'text') {
    if (!input || input.length > 500) return fail(400, 'Isi teks (maksimal 500 karakter).');
    if (tool.stripAt) input = input.replace(/^@+/, '');
    if (tool.upper) input = input.toUpperCase();
    if (tool.pattern && !tool.pattern.test(input)) return fail(400, tool.patternMsg || 'Format isian tidak valid.');
  } else if (tool.type === 'multi') {
    const fl = body.fields && typeof body.fields === 'object' ? body.fields : {};
    multi = {};
    for (const f of tool.fields) {
      const v = String(fl[f.key] === undefined || fl[f.key] === null ? '' : fl[f.key]).trim();
      if (!v) { if (f.req) return fail(400, f.label + ' wajib diisi.'); continue; }
      if (v.length > (f.max || 2000)) return fail(400, f.label + ' terlalu panjang (maksimal ' + (f.max || 2000) + ' karakter).');
      if (f.kind === 'url') { try { const u = new URL(v); if (!/^https?:$/.test(u.protocol)) throw 0; } catch { return fail(400, f.label + ' harus berupa link yang diawali https://'); } }
      multi[f.key] = v;
    }
    input = Object.values(multi)[0] || '';
  } else if (tool.type === 'number') {
    if (!/^\d{1,9}$/.test(input)) return fail(400, 'Jumlah point harus berupa angka.');
  } else {
    try { const u = new URL(input); if (!/^https?:$/.test(u.protocol)) throw 0; if (tool.host && !tool.host.test(u.hostname)) return fail(400, tool.hostMsg || 'Link harus dari TikTok (tiktok.com, vt.tiktok.com, atau tt.site).'); } catch { return fail(400, 'Link tidak valid. Gunakan link yang diawali https://'); }
    if (tool.extra) { // parameter kedua (mis. emoji reaction)
      link2 = String(body.link || '').trim();
      if (!link2 || link2.length > 20) return fail(400, 'Isi emoji reaction (maksimal 20 karakter).');
    }
  }

  // Harga: pengaturan developer (panel Tools) lebih dulu, bila tidak ada pakai harga bawaan
  let price = credits.cost(tid, custom);
  if (store.ready()) {
    try { const ov = await store.getTool(tid); const n = ov ? parseInt(ov.credit, 10) : NaN; if (Number.isFinite(n)) price = Math.max(0, Math.min(99, n)); }
    catch (e) { /* Redis bermasalah: pakai harga bawaan */ }
  }
  let reserved = 0, done = false, cr = null;
  if (price) { // tool berkredit: wajib login. Kredit dipesan (dipotong) atomik dulu; bila provider gagal, dikembalikan di blok finally
    if (!me) return fail(401, 'Masuk dulu untuk memakai tool ini.');
    if (isOwner(me.email)) cr = credits.info(null, 'developer');
    else if (store.ready()) {
      try {
        const rec = await store.mutateUser(me.sub, (r) => {
          r = r || { firstSeen: Date.now(), logins: 0, email: me.email, name: me.name };
          const ci = credits.info(r, roleOf(me.email, r));
          if (!ci.unlimited) {
            if (ci.left < price) { const err = new Error('NOCREDIT'); err.ci = ci; throw err; }
            credits.charge(r, price);
          }
          return r;
        });
        reserved = price; cr = credits.info(rec, roleOf(me.email, rec));
      } catch (e) {
        if (e && e.message === 'NOCREDIT')
          return res.status(429).json({ ok: false, error: 'Kredit harian habis. Kredit kembali setelah 24 jam sejak pemakaian pertama.', credits: e.ci });
        return fail(503, 'Data kredit belum bisa dibaca. Coba lagi sebentar lagi.');
      }
    }
  }

  const mkHeaders = (t) => ({ ...(t.base ? {} : { Authorization: 'Bearer ' + cfg.key, 'x-api-key': cfg.key }), 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', Accept: 'application/json, text/plain, */*' });

  // Satu percobaan ke satu provider. Hasil: { ok:true, link, data } atau { ok:false, code, error, retry }.
  // retry:true = kegagalan di sisi provider (boleh dicoba lewat jalur cadangan).
  async function attempt(t, ms) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), ms);
    const headers = mkHeaders(t);
    try {
      let r;
      if (t.method === 'GET') {
        const u = new URL((t.base || cfg.base) + t.path);
        if (t.keyParam) u.searchParams.set(t.keyParam, cfg.key);
        if (multi) { for (const k of Object.keys(multi)) u.searchParams.set(k, multi[k]); }
        else { u.searchParams.set(t.param, input); if (t.linkParam) u.searchParams.set(t.linkParam, link2); }
        r = await fetch(u, { headers, signal: ctrl.signal });
      } else {
        r = await fetch(cfg.base + t.path, {
          method: 'POST', headers: { ...headers, 'Content-Type': 'application/json' },
          body: JSON.stringify({ [cfg.emailField]: input, apikey: cfg.key }), signal: ctrl.signal
        });
      }
      const ct = r.headers.get('content-type') || '';
      if (r.ok && ct.startsWith('image/')) { // provider mengembalikan gambar langsung
        const buf = Buffer.from(await r.arrayBuffer());
        if (buf.length > MAX_IMG_RAW) return { ok: false, code: 502, error: 'Hasil gambar terlalu besar untuk ditampilkan (maksimal sekitar 3,2 MB).' };
        return { ok: true, link: 'data:' + ct + ';base64,' + buf.toString('base64'), data: {} };
      }
      const text = await r.text();
      const hp = htmlProblem(r.status, text);
      if (hp) return { ok: false, code: 502, error: hp.msg, retry: true, transient: !!hp.transient };
      let data; try { data = JSON.parse(text); } catch { data = { message: text.slice(0, 500) }; }
      if (data && (data.status === false || data.success === false)) // provider membalas HTTP 200 tetapi status:false
        return { ok: false, code: 502, error: typeof data.result === 'string' ? data.result : (data.message || data.error || 'Provider menolak permintaan.'), retry: true };
      if (!r.ok) return { ok: false, code: 502, error: (data && (data.message || data.error)) || 'Provider menolak permintaan (' + r.status + ').', retry: true, transient: r.status >= 500 };
      const dimg = findDataImage(data);
      if (dimg) {
        if (dimg.length > MAX_IMG_RAW * 1.34) return { ok: false, code: 502, error: 'Hasil gambar terlalu besar untuk ditampilkan (maksimal sekitar 3,2 MB).' };
        return { ok: true, link: dimg, data: stripDataImage(data, dimg) };
      }
      if (t.shape === 'tiktok') {
        const x = tiktok(data);
        if (!x) return { ok: false, code: 502, error: 'Provider tidak mengembalikan video atau foto. Pastikan link TikTok publik, lalu coba lagi.', retry: true };
        return { ok: true, link: x.link, data: x.data };
      }
      if (t.shape === 'aio') {
        const x = aio(data);
        if (!x) return { ok: false, code: 502, error: 'Provider tidak mengembalikan media. Pastikan link publik dan didukung, lalu coba lagi.', retry: true };
        return { ok: true, link: x.link, data: x.data };
      }
      return { ok: true, link: (t.type === 'email-link' || t.type === 'number') ? null : findLink(data, t.type === 'url' ? input : null), data };
    } catch (e) {
      const to = e && e.name === 'AbortError';
      return { ok: false, code: 504, error: to ? 'Provider terlalu lama merespons.' : 'Gagal menghubungi provider.', retry: true, transient: !to };
    } finally { clearTimeout(timer); }
  }

  try {
    // Jalur utama, lalu jalur cadangan (tool.fallback, mis. AIO Nexa) bila provider utama gagal/diblokir.
    // Total waktu dijaga di bawah batas fungsi Vercel (45 detik).
    const T0 = Date.now(), BUDGET = 57000;
    const chain = [tool];
    const fb = tool.fallback && cfg.key && Object.prototype.hasOwnProperty.call(cfg.tools, tool.fallback) ? cfg.tools[tool.fallback] : null;
    if (fb) chain.push(fb);
    // Kegagalan sementara (HTTP 5xx / koneksi putus) diulang otomatis, tetapi hanya untuk tool yang aman diulang (t.retries).
    const run = async (t, minLeft) => {
      let o = null;
      for (let n = 0; n <= (t.retries || 0); n++) {
        const left = BUDGET - (Date.now() - T0);
        if (left < (n === 0 ? minLeft : 6000)) break;
        o = await attempt(t, Math.max(3000, Math.min(t.timeout || 25000, left)));
        if (o.ok || !o.transient || n === (t.retries || 0)) break;
        await new Promise((r) => setTimeout(r, 1200));
      }
      return o;
    };
    let out = null, first = null;
    for (let i = 0; i < chain.length; i++) {
      const o = await run(chain[i], i === 0 ? 0 : 8000);
      if (!o) break;
      out = o;
      if (out.ok || !out.retry) break;
      if (i === 0) first = out;
    }
    if (!out) return fail(504, 'Provider terlalu lama merespons.');
    if (!out.ok) {
      let msg = out.error;
      if (first && first !== out) msg = (first.error + ' Jalur cadangan juga gagal: ' + out.error).slice(0, 400);
      return fail(out.code, msg);
    }
    done = true;
    return res.status(200).json({ ok: true, link: out.link, data: out.data, credits: cr });
  } catch (e) {
    return fail(504, 'Gagal menghubungi provider.');
  } finally {
    if (reserved && !done) { // provider gagal / timeout / hasil ditolak: kredit yang sudah dipesan dikembalikan
      try { await store.mutateUser(me.sub, (r) => { if (!r) return null; credits.refund(r, reserved); return r; }); }
      catch (e) { console.error('[refund]', e && e.message); }
    }
    // foto yang diunggah dari perangkat dihapus lagi setelah diproses
    // Hanya file di folder uploads/ pada host Blob yang boleh dihapus (bukan avatar/chat/data milik orang lain)
    const cands = multi ? Object.values(multi) : (tool.type === 'url' ? [input] : []);
    for (const c of cands) {
      let up = null; try { up = new URL(c); } catch (e) { /* bukan URL */ }
      if (blob && up && up.protocol === 'https:' && /\.public\.blob\.vercel-storage\.com$/.test(up.hostname) && /^\/uploads\/[^/]+$/.test(up.pathname)) {
        try { await blob.del(c); } catch (e) { /* abaikan */ }
      }
    }
  }
};
