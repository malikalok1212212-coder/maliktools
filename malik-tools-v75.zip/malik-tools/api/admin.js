const cfg = require('./_config');
const { getUser, isOwner, ROLES, roleOf } = require('./_auth');
const store = require('./_store');
const rate = require('./_rate');
let blob = null;
try { blob = require('@vercel/blob'); } catch (e) { /* opsional */ }

// Poster pengumuman: gambar data-URI dari browser (sudah dikecilkan) disimpan di Vercel Blob folder poster/
function sniff(b) {
  if (b.length > 12 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { ext: 'jpg', mime: 'image/jpeg' };
  if (b.length > 12 && b.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { ext: 'png', mime: 'image/png' };
  if (b.length > 12 && b.slice(0, 4).toString() === 'RIFF' && b.slice(8, 12).toString() === 'WEBP') return { ext: 'webp', mime: 'image/webp' };
  return null;
}
async function dropPoster(url) { // hanya file poster/ di host Blob, best effort
  try {
    const u = new URL(url);
    if (blob && process.env.BLOB_READ_WRITE_TOKEN && u.protocol === 'https:' && /\.public\.blob\.vercel-storage\.com$/.test(u.hostname) && /^\/poster\//.test(u.pathname)) await blob.del(url);
  } catch (e) { /* abaikan */ }
}

// Harga tool yang diatur developer: { idTool: jumlahKredit }. 0 = gratis. Tool tanpa entri memakai harga bawaan.
function pricesOf(m) {
  const out = {};
  for (const id of Object.keys(m || {})) {
    if (!Object.prototype.hasOwnProperty.call(cfg.tools, id)) continue;
    const n = parseInt(m[id] && m[id].credit, 10);
    if (Number.isFinite(n) && n >= 0 && n <= 99) out[id] = n;
  }
  return out;
}

const clip = (v, n) => String(v == null ? '' : v).trim().slice(0, n);

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const fail = (code, error) => res.status(code).json({ ok: false, error });
  const action = String((req.query && req.query.action) || '');
  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = {}; } }
  body = body || {};
  const me = getUser(req);

  try {
    // Publik: pengumuman aktif
    if (action === 'tools' && req.method === 'GET') {
      const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'x';
      if (await rate.limited('tools', ip, 60, 60)) return fail(429, 'Terlalu banyak permintaan. Coba lagi sebentar lagi.');
      const st = await store.getTools(); // hanya pengumuman dan harga tool, tanpa memuat daftar pengguna
      return res.status(200).json({ ok: true, tools: [], prices: pricesOf(st && st.tools), announce: st ? st.announce : null });
    }

    // Pengguna: tandai peringatan sudah dibaca
    if (action === 'ack' && req.method === 'POST') {
      if (!me) return fail(403, 'Belum masuk.');
      if (store.ready()) await store.mutateUser(me.sub, (r) => { if (!r || !r.warning) return null; delete r.warning; return r; }); // satu pengguna, tanpa memuat semua
      return res.status(200).json({ ok: true });
    }

    // Selanjutnya khusus developer
    if (!me || !isOwner(me.email)) return fail(403, 'Khusus developer.');
    const st = await store.load();
    if (!st) return fail(500, 'Upstash Redis belum diatur, data developer belum bisa disimpan.');

    if (action === 'overview' && req.method === 'GET') {
      const users = Object.entries(st.users).map(([sub, u]) => ({ sub, ...u, owner: isOwner(u.email), role: roleOf(u.email, u) }))
        .sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0));
      return res.status(200).json({ ok: true, store: true, users, tools: [], prices: pricesOf(st.tools), announce: st.announce });
    }
    if (req.method !== 'POST') return fail(405, 'Metode tidak diizinkan.');

    if (action === 'user') {
      const u = st.users[body.sub];
      if (!u) return fail(404, 'Pengguna tidak ditemukan.');
      const op = body.op;
      if ((op === 'ban' || op === 'remove' || op === 'warn' || op === 'role') && isOwner(u.email)) return fail(400, 'Akun developer tidak bisa diubah.');
      if (op === 'warn') { const t = clip(body.text, 300); if (!t) return fail(400, 'Isi peringatan dulu.'); u.warning = t; u.warnedAt = Date.now(); }
      else if (op === 'unwarn') delete u.warning;
      else if (op === 'role') { if (!ROLES.includes(body.role)) return fail(400, 'Role tidak dikenal.'); if (body.role === 'member') delete u.role; else u.role = body.role; }
      else if (op === 'ban') u.banned = true;
      else if (op === 'unban') delete u.banned;
      else if (op === 'remove') { if (u.banned) return fail(400, 'Pengguna ini sedang diblokir. Menghapusnya akan menghilangkan blokir, jadi buka blokir dulu bila memang ingin menghapus.'); delete st.users[body.sub]; }
      else return fail(400, 'Aksi tidak dikenal.');
      await store.save(st);
      return res.status(200).json({ ok: true });
    }

    if (action === 'price') { // atur tool gratis atau berkredit
      const id = String(body.tool || '');
      if (!Object.prototype.hasOwnProperty.call(cfg.tools, id)) return fail(400, 'Tool tidak dikenal.');
      const n = Math.floor(Number(body.credit));
      if (!Number.isFinite(n) || n < 0 || n > 99) return fail(400, 'Biaya harus angka 0 sampai 99 kredit.');
      st.tools[id] = { id, credit: n };
      await store.save(st);
      return res.status(200).json({ ok: true });
    }

    if (action === 'announce') {
      const t = clip(body.text, 300), title = clip(body.title, 60);
      const link = /^https:\/\/[^\s]{4,290}$/.test(clip(body.link, 300)) ? clip(body.link, 300) : '', btn = clip(body.btn, 24) || 'Buka';
      const old = st.announce && st.announce.img || '';
      let img = body.keepImg ? old : '';
      if (typeof body.img === 'string' && body.img) {
        if (!blob || !process.env.BLOB_READ_WRITE_TOKEN) return fail(500, 'Poster butuh Vercel Blob (Storage) yang sudah terhubung.');
        const m = /^data:image\/(?:jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/.exec(body.img);
        if (!m) return fail(415, 'Format gambar tidak didukung. Gunakan JPG, PNG, atau WebP.');
        const buf = Buffer.from(m[1], 'base64');
        if (buf.length > 2.5 * 1024 * 1024) return fail(413, 'Gambar poster terlalu besar (maksimal sekitar 2,5 MB).');
        const type = sniff(buf);
        if (!type) return fail(415, 'Format gambar tidak didukung. Gunakan JPG, PNG, atau WebP.');
        img = (await blob.put('poster/poster.' + type.ext, buf, { access: 'public', addRandomSuffix: true, contentType: type.mime })).url;
      }
      st.announce = (t || img || title) ? { title, text: t, img, link, btn, ts: Date.now() } : null;
      await store.save(st);
      if (old && old !== img) await dropPoster(old);
      return res.status(200).json({ ok: true });
    }

    return fail(action ? 405 : 404, 'Aksi tidak dikenal.');
  } catch (e) {
    console.error('[admin]', e && e.name, e && e.message);
    return fail(500, 'Penyimpanan bermasalah, coba lagi.');
  }
};
